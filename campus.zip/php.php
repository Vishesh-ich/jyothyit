<?php 
   $txt="Hello World!";
   $x=10;
   $y=10.5;
   $z=$x+$y;
?>